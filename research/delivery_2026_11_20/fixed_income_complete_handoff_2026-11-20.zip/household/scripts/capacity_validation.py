"""Literature-informed capacity measurement audit and SCF/SHED validation.

All models are exploratory associations. The original analysis is left intact.
"""
from pathlib import Path
import io
import json
import zipfile
import re
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
from scf_analysis import Survey, survey_model, prepare, age_contrast

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'capacity_validation'
OUT = ROOT / 'outputs' / 'capacity_validation'
OUT.mkdir(parents=True, exist_ok=True)
AGE = ['age10', 'age45plus', 'age65plus']
DEMO = ['female', 'partnered', 'children', 'education2', 'education3', 'education4']
LABELS = {
    'capacity_proxy': 'Original composite (includes saving behavior)',
    'capacity_no_saving': 'Original composite without saving behavior',
    'liquid_buffer_log': 'Liquid buffer: log(1 + months of usual income)',
    'payment_headroom': 'Debt-service headroom',
    'income_predictable': 'Usually knows next-year income',
    'networth_asinh': 'Net worth: asinh(real dollars / 100,000)',
    'liquid_ge3months': 'Liquid assets cover 3 months of usual income',
}


def read_zip(path, extension, **kwargs):
    with zipfile.ZipFile(path) as z:
        member = next(n for n in z.namelist() if n.lower().endswith(extension))
        if extension == '.csv':
            return pd.read_csv(z.open(member), **kwargs)
        return pd.read_stata(z.open(member), convert_categoricals=False, **kwargs)


def load_wave(year):
    folder = ROOT / 'data' / 'raw' if year == 2025 else DATA
    d = read_zip(folder / f'scfp{year}excel.zip', '.csv').copy()
    d.columns = d.columns.str.upper()
    columns = ['y1', 'yy1', 'x7557', 'x3014', 'x7510', 'x42001', 'x7366', 'x7586', 'x6443']
    raw = read_zip(folder / f'scf{year}s.zip', '.dta', columns=columns)
    raw.columns = raw.columns.str.upper()
    d = d.merge(raw, on=['Y1', 'YY1'], validate='one_to_one', indicator=True)
    assert d['_merge'].eq('both').all()
    d = d.drop(columns='_merge').copy()
    d.WGT = d.WGT * 5
    assert np.allclose(d.WGT, d.X42001)
    d['imp'] = d.Y1 % 10
    assert d.groupby('YY1').imp.nunique().eq(5).all()
    d = prepare(d.sort_values('Y1').reset_index(drop=True))
    d['year'] = year
    d['any_risk'] = d.X3014.le(3).astype(float)
    d['high_risk'] = d.X3014.le(2).astype(float)
    d['income_predictable'] = d.X7366.map({1: 1., 5: 0.})
    d['income_predictable_current'] = d.X7586.map({1: 1., 5: 0.})
    d['social_backstop'] = d.X6443.map({1: 1., 5: 0.})
    d['liquid_months'] = 12 * d.LIQ / d.NORMINC.where(d.NORMINC.gt(0))
    d['liquid_buffer_log'] = np.log1p(d.liquid_months)
    d['liquid_ge3months'] = d.liquid_months.ge(3).astype(float).where(d.liquid_months.notna())
    d['networth_asinh'] = np.arcsinh(d.NETWORTH / 100_000)
    d['late60'] = d.LATE60.astype(float)
    r = read_zip(folder / f'scf{year}rw1s.zip', '.dta')
    r.columns = r.columns.str.lower()
    r = r.set_index('yy1')
    ids = d.loc[d.imp.eq(1), 'YY1'].to_numpy()
    r = r.loc[ids]
    rw = np.column_stack([r[f'wt1b{i}'].fillna(0).clip(lower=0).to_numpy()
                          * r[f'mm{i}'].fillna(0).clip(lower=0).to_numpy() for i in range(1, 1000)])
    assert np.max(np.abs(rw.sum(axis=0) / d.loc[d.imp.eq(1), 'WGT'].sum()-1)) < .01
    return d.loc[d.AGE.between(20, 89)].copy(), pd.DataFrame(rw, index=ids)


def scalar_result(result, i=0):
    b = float(result['estimate'][i]); se = float(result['se'][i])
    return {'estimate': b, 'se': se, 'low': b-1.96*se, 'high': b+1.96*se,
            'p_normal': float(2*norm.sf(abs(b/se))) if se > 0 else np.nan}


def index_audit(d):
    rows = []
    components = ['income_resource', 'payment_headroom', 'saving_surplus']
    for m in range(1, 6):
        f = d.loc[d.imp.eq(m)]
        x = f[components].to_numpy(); w = f.WGT.to_numpy(); w = w/w.sum()
        means = w@x
        cov = ((x-means)*w[:, None]).T@(x-means)
        contributions = cov.sum(axis=1)/cov.sum()
        for j, c in enumerate(components):
            rows.append({'imp': m, 'component': c, 'mean': means[j],
                         'sd': np.sqrt(cov[j, j]), 'index_variance_share': contributions[j]})
    return pd.DataFrame(rows).groupby('component', as_index=False).mean().drop(columns='imp')


def run_scf():
    correlations, effects, flows, audits, ages, profiles = [], [], [], [], [], []
    last = None
    measures = list(LABELS)
    for year in [2016, 2019, 2022, 2025]:
        print('Analyzing SCF:', year, flush=True)
        d, rw = load_wave(year)
        flows.append({'dataset': 'SCF', 'year': year, 'age20_89_imp1': int(d.imp.eq(1).sum()),
                      'positive_income_imp1': int((d.imp.eq(1)&d.NORMINC.gt(0)).sum()),
                      'missing_usual_income_predictability_imp1': int((d.imp.eq(1)&d.income_predictable.isna()).sum())})
        a = index_audit(d); a['year'] = year; audits.append(a)
        survey = Survey(d, rw)
        for measure in measures:
            r = scalar_result(survey.correlation('tolerance', measure))
            correlations.append({'year': year, 'measure': measure, 'label': LABELS[measure], **r})
            # The primary outcome avoids imposing equal spacing on willingness categories.
            for outcome in ['any_risk', 'high_risk', 'tolerance']:
                unit = .1 if measure.startswith('capacity_') else 1.
                f = d.copy()
                if measure in ['liquid_buffer_log', 'networth_asinh']:
                    scales = []
                    for m in range(1, 6):
                        sub = f.loc[f.imp.eq(m)&f[measure].notna()]
                        w = sub.WGT.to_numpy(); x = sub[measure].to_numpy()
                        mean = np.average(x, weights=w)
                        scales.append(np.sqrt(np.average((x-mean)**2, weights=w)))
                    unit = float(np.mean(scales))
                f['capacity_term'] = f[measure]/unit
                # Resource-adjusted models do not re-add income for an index containing income.
                cols = AGE+DEMO+['capacity_term']
                if measure not in ['capacity_proxy', 'capacity_no_saving']:
                    cols += ['income_log']
                model = survey_model(Survey(f, rw), cols, outcome)
                i = model['columns'].index('capacity_term')
                e = scalar_result(model, i)
                effects.append({'year': year, 'measure': measure, 'outcome': outcome,
                                'unit_change': unit, 'unit_label': '0.1 index unit' if measure.startswith('capacity_') else ('1 within-wave SD' if measure in ['liquid_buffer_log', 'networth_asinh'] else '0 to 1'),
                                'income_adjusted': 'income_log' in cols, **e})
        # Revised dimensions jointly; none is chosen for a positive coefficient.
        cols = AGE+DEMO+['income_log', 'liquid_buffer_log', 'payment_headroom', 'income_predictable']
        model = survey_model(survey, cols, 'any_risk')
        table = model['table'].copy(); table['year'] = year
        table.to_csv(OUT / f'scf_{year}_joint_any_risk.csv', index=False)
        wealth_model = survey_model(survey, cols+['networth_asinh'], 'any_risk')
        table = wealth_model['table'].copy(); table['year'] = year
        table.to_csv(OUT / f'scf_{year}_joint_any_risk_wealth.csv', index=False)
        for outcome in ['tolerance', 'any_risk', 'liquid_ge3months', 'payment_headroom', 'income_predictable']:
            model = survey_model(survey, AGE+DEMO, outcome)
            ages.append({'year': year, 'outcome': outcome, **age_contrast(model, scale=1)})
        # Conditional capacity profile by each of the eleven willingness categories.
        d['score_group'] = d.tolerance.astype(int)
        for measure in ['liquid_ge3months', 'income_predictable', 'capacity_no_saving']:
            t = Survey(d, rw).grouped(measure, 'score_group', list(range(11)))
            t['year'] = year; t['measure'] = measure; profiles.append(t)
        last = (d, rw)
    correlations = pd.DataFrame(correlations)
    effects = pd.DataFrame(effects)
    primary = effects.outcome.eq('any_risk') & effects.measure.isin(['liquid_buffer_log', 'payment_headroom', 'income_predictable'])
    effects['p_holm_primary_12'] = np.nan
    effects.loc[primary, 'p_holm_primary_12'] = multipletests(effects.loc[primary, 'p_normal'], method='holm')[1]
    result = {'scf_correlations': correlations, 'scf_effects': effects, 'scf_sample_flow': pd.DataFrame(flows),
              'index_audit': pd.concat(audits), 'scf_age_contrasts': pd.DataFrame(ages),
              'scf_score_profiles': pd.concat(profiles)}
    for name, frame in result.items():
        frame.to_csv(OUT / f'{name}.csv', index=False)
    return result


def load_shed(year):
    path = DATA / f'SHED_public_use_data_{year}_(CSV).zip'
    with zipfile.ZipFile(path) as z:
        payload = z.read(next(n for n in z.namelist() if n.lower().endswith('.csv')))
    try:
        text = payload.decode('utf-8-sig')
    except UnicodeDecodeError:
        text = payload.decode('cp1252')
    d = pd.read_csv(io.StringIO(text), low_memory=False)
    assert d.shedid.is_unique
    return d


def yes_no(series):
    return series.map({'Yes': 1., 'No': 0.})


def prepare_shed(raw, year):
    d = raw.copy()
    d['year'] = year
    d['age'] = pd.to_numeric(d.ppage, errors='coerce')
    d['age10'] = (d.age-50)/10
    d['age45plus'] = (d.age-45).clip(lower=0)/10
    d['age65plus'] = (d.age-65).clip(lower=0)/10
    d['female'] = d.ppgender.map({'Female': 1., 'Male': 0.})
    marital = d['ppmarit'] if 'ppmarit' in d else d.ppmarit5
    if 'ppmarit5' in d:
        # Some waves retain an entirely empty legacy field alongside the labeled field.
        marital = marital.fillna(d.ppmarit5)
    d['married'] = marital.isin(['Married', 'Now married']).astype(float)
    education = d.ppeducat
    d['education_group'] = np.select([education.str.contains('Bachelor', na=False),
                                     education.str.contains('Some college', na=False),
                                     education.str.startswith('High school', na=False)], [4, 3, 2], default=1)
    income = d['ppincimp'] if 'ppincimp' in d else d.ppinc7

    def income_group(value):
        if not isinstance(value, str):
            return np.nan
        if value.startswith('Less than'):
            low = 0
        else:
            match = re.search(r'\$([\d,]+)', value)
            if match is None:
                return np.nan
            low = int(match.group(1).replace(',', ''))
        return np.searchsorted([10_000, 25_000, 50_000, 75_000, 100_000, 150_000], low, side='right')+1

    d['income_group'] = income.map(income_group)
    assert d.income_group.notna().all()
    for c in [2, 3, 4]:
        d[f'education{c}'] = d.education_group.eq(c).astype(float)
    for c in range(2, 8):
        d[f'income{c}'] = d.income_group.eq(c).astype(float)
    d['emergency_fund'] = yes_no(d.EF1)
    if 'EF7' in d:
        expense = d.EF7.copy()
        if 'EF7A' in d:
            # Split-ballot versions have different upper categories; their $2,000 boundary agrees.
            assert (d.EF7.notna().astype(int)+d.EF7A.notna().astype(int)).eq(1).all()
            expense = expense.fillna(d.EF7A)
        known = expense.isin(['Under $100', '$100 to $499', '$500 to $999', '$1,000 to $1,999',
                              '$2,000 or more', '$2,000 to $4,999', '$5,000 or more'])
        d['own_savings_ge2000'] = expense.isin(['$2,000 or more', '$2,000 to $4,999', '$5,000 or more']).astype(float).where(known)
    d['stable_income'] = d.I9.map({'Roughly the same amount each month': 1.,
                                  'Occasionally varies from month to month': 0.,
                                  'Varies quite often from month to month': 0.})
    if 'FL0' in d:
        d['tolerance'] = pd.to_numeric(d.FL0, errors='coerce')
        d.loc[d.FL0.astype(str).str.contains('Not at all', case=False), 'tolerance'] = 0
        d.loc[d.FL0.astype(str).str.contains('Very willing', case=False), 'tolerance'] = 10
    for c in 'abcdefgh':
        d[f'emergency_{c}'] = yes_no(d[f'EF3_{c}'])
    cols = [f'emergency_{c}' for c in 'abcdefgh']
    complete = d[cols].notna().all(axis=1)
    own_cash = d.emergency_a.eq(1)|d.emergency_c.eq(1)
    other = d[[f'emergency_{c}' for c in 'bdefgh']].eq(1).any(axis=1)
    d['cash_equivalent_only'] = (own_cash & ~other).astype(float).where(complete)
    if 'EF5C' in d:
        d['unpaid_bills'] = 1-yes_no(d.EF5C)
    else:
        d['unpaid_bills'] = d.EF5A.map({'Able to pay all bills': 0., 'Can’t pay some bills': 1.})
        d['safe_after_400'] = d.EF5B.map({'Would still be able to pay all bills': 1., 'Could not pay some bills': 0.})
        d.loc[d.unpaid_bills.eq(1), 'safe_after_400'] = 0.
    # A common adult-age restriction improves comparability but does not equate populations.
    return d.loc[d.age.between(20, 89)].copy()


SHED_DEMO = AGE+['female', 'married', 'education2', 'education3', 'education4']
SHED_INCOME = [f'income{i}' for i in range(2, 8)]


def hc3_effect(d, outcome, predictors, term, weight='weight'):
    cols = list(dict.fromkeys(predictors))
    f = d.dropna(subset=[outcome, weight, *cols]).copy()
    f = f.loc[f[weight].gt(0)]
    x = sm.add_constant(f[cols], has_constant='add')
    model = sm.WLS(f[outcome], x, weights=f[weight]).fit(cov_type='HC3')
    i = model.params.index.get_loc(term)
    b = float(model.params.iloc[i]); se = float(model.bse.iloc[i])
    return {'estimate': b, 'se': se, 'low': b-1.96*se, 'high': b+1.96*se,
            'p_normal': float(2*norm.sf(abs(b/se))), 'n': len(f)}


def weighted_corr(d, a, b, weight='weight'):
    f = d.dropna(subset=[a, b, weight])
    w = f[weight].to_numpy(); x = f[a].to_numpy(); y = f[b].to_numpy()
    mx = np.average(x, weights=w); my = np.average(y, weights=w)
    return np.average((x-mx)*(y-my), weights=w)/np.sqrt(np.average((x-mx)**2, weights=w)*np.average((y-my)**2, weights=w))


def run_shed():
    frames = {y: prepare_shed(load_shed(y), y) for y in [2018, 2019, 2024, 2025]}
    effects, corrs, profiles, flows = [], [], [], []
    for year in [2018, 2019, 2025]:
        print('Analyzing SHED:', year, flush=True)
        d = frames[year]
        flows.append({'year': year, 'age20_89': len(d), 'tolerance_observed': int(d.tolerance.notna().sum()),
                      'weight_column': 'weight', 'emergency_fund_observed': int(d.emergency_fund.notna().sum())})
        measures = ['emergency_fund', 'cash_equivalent_only', 'stable_income']
        if 'own_savings_ge2000' in d:
            measures.append('own_savings_ge2000')
        for measure in measures:
            corrs.append({'year': year, 'measure': measure, 'correlation': weighted_corr(d, 'tolerance', measure)})
            for controls, label in [(SHED_DEMO, 'Demographics'), (SHED_DEMO+SHED_INCOME, 'Demographics + income')]:
                e = hc3_effect(d, 'tolerance', controls+[measure], measure)
                effects.append({'year': year, 'measure': measure, 'adjustment': label, **e})
        # Newer SHED releases impute selected items; verify sensitivity to flags.
        if year == 2025:
            f = d.loc[d.FL0_iflag.eq(0)&d.EF1_iflag.eq(0)]
            e = hc3_effect(f, 'tolerance', SHED_DEMO+SHED_INCOME+['emergency_fund'], 'emergency_fund')
            effects.append({'year': year, 'measure': 'emergency_fund', 'adjustment': 'Demographics + income; non-imputed key items', **e})
        for score in range(11):
            f = d.loc[d.tolerance.eq(score)&d.emergency_fund.notna()]
            # HC3 interval for a weighted intercept, not a full survey-design interval.
            e = hc3_effect(f, 'emergency_fund', [], 'const')
            profiles.append({'year': year, 'score': score, **e})

    # Within-person changes: explicitly exploratory, with no longitudinal public weight in 2019.
    a = frames[2018][['shedid', 'tolerance', 'emergency_fund', 'income_group']]
    b = frames[2019][['shedid', 'tolerance', 'emergency_fund', 'income_group']]
    panel = a.merge(b, on='shedid', suffixes=('_2018', '_2019'), validate='one_to_one').dropna()
    panel['delta_tolerance'] = panel.tolerance_2019-panel.tolerance_2018
    panel['delta_fund'] = panel.emergency_fund_2019-panel.emergency_fund_2018
    panel['delta_income_group'] = panel.income_group_2019-panel.income_group_2018
    panel['unit_weight'] = 1.
    within = hc3_effect(panel, 'delta_tolerance', ['delta_fund', 'delta_income_group'], 'delta_fund', 'unit_weight')
    within.update({'dataset': 'SHED 2018-2019 matched respondents', 'weighting': 'Unweighted retained-panel association',
                   'transitions': panel.delta_fund.value_counts().sort_index().to_dict()})

    # Prospective criterion: does the baseline buffer predict next-year unpaid bills?
    a = frames[2024][['shedid', 'emergency_fund', 'own_savings_ge2000', 'unpaid_bills', 'stable_income', *SHED_DEMO, *SHED_INCOME]]
    b = frames[2025][['shedid', 'unpaid_bills', 'panel_weight']].rename(columns={'unpaid_bills': 'unpaid_next_year'})
    future = a.merge(b, on='shedid', validate='one_to_one')
    future = future.loc[future.panel_weight.gt(0)].copy()
    prospective = []
    for columns, label in [(SHED_DEMO+SHED_INCOME+['emergency_fund'], 'Demographics + income'),
                           (SHED_DEMO+SHED_INCOME+['unpaid_bills', 'stable_income', 'emergency_fund'], 'Also baseline unpaid bills + income stability')]:
        e = hc3_effect(future, 'unpaid_next_year', columns, 'emergency_fund', 'panel_weight')
        prospective.append({'measure': 'emergency_fund', 'adjustment': label, **e})
    columns = SHED_DEMO+SHED_INCOME+['unpaid_bills', 'stable_income', 'own_savings_ge2000']
    e = hc3_effect(future, 'unpaid_next_year', columns, 'own_savings_ge2000', 'panel_weight')
    prospective.append({'measure': 'own_savings_ge2000', 'adjustment': 'Also baseline unpaid bills + income stability', **e})
    group_risk = []
    for flag in [0, 1]:
        f = future.loc[future.emergency_fund.eq(flag)].dropna(subset=['unpaid_next_year'])
        group_risk.append({'baseline_fund': flag, 'n': len(f),
                           'next_year_unpaid_rate': np.average(f.unpaid_next_year, weights=f.panel_weight)})
    results = {'shed_effects': pd.DataFrame(effects), 'shed_correlations': pd.DataFrame(corrs),
               'shed_score_profiles': pd.DataFrame(profiles), 'shed_sample_flow': pd.DataFrame(flows),
               'shed_prospective': pd.DataFrame(prospective), 'shed_prospective_groups': pd.DataFrame(group_risk)}
    for name, frame in results.items():
        frame.to_csv(OUT / f'{name}.csv', index=False)
    # A categorical willingness predictor avoids imposing a monotonic linear slope.
    categorical = []
    d = frames[2025].dropna(subset=['tolerance', 'emergency_fund']).copy()
    terms = []
    for score in range(1, 11):
        term = f'score_{score}'
        d[term] = d.tolerance.eq(score).astype(float)
        terms.append(term)
    cols = SHED_DEMO+SHED_INCOME+terms
    x = sm.add_constant(d[cols], has_constant='add')
    model = sm.WLS(d.emergency_fund, x, weights=d.weight).fit(cov_type='HC3')
    center = np.average(x, axis=0, weights=d.weight)
    for score in range(11):
        v = center.copy()
        for term in terms:
            v[x.columns.get_loc(term)] = float(term == f'score_{score}')
        b = float(v@model.params)
        se = float(np.sqrt(v@model.cov_params()@v))
        categorical.append({'score': score, 'estimate': b, 'se': se,
                            'low': b-1.96*se, 'high': b+1.96*se})
    results['shed_2025_adjusted_score_profile'] = pd.DataFrame(categorical)
    results['shed_2025_adjusted_score_profile'].to_csv(OUT/'shed_2025_adjusted_score_profile.csv', index=False)
    cv = prospective_cv(future)
    results['shed_prospective_cv'] = cv
    cv.to_csv(OUT/'shed_prospective_cv.csv', index=False)
    (OUT/'shed_within_person.json').write_text(json.dumps(within, indent=2), encoding='utf-8')
    results['within'] = within
    return results


def prospective_cv(data, seed=20261026):
    """Respondent-held-out prediction of 2025 hardship from 2024 measurements."""
    baseline = SHED_DEMO+SHED_INCOME+['unpaid_bills', 'stable_income']
    columns = baseline+['emergency_fund']
    d = data.dropna(subset=['unpaid_next_year', 'panel_weight', *columns]).sort_values('shedid').copy()
    rng = np.random.default_rng(seed)
    folds = np.empty(len(d), dtype=int)
    folds[rng.permutation(len(d))] = np.arange(len(d))%5
    y = d.unpaid_next_year.to_numpy(); w = d.panel_weight.to_numpy()
    rows = []
    for name, predictors in [('Baseline', baseline), ('Add emergency fund', columns)]:
        x = sm.add_constant(d[predictors], has_constant='add').to_numpy()
        pred = np.zeros(len(d))
        for k in range(5):
            train = folds != k; test = folds == k
            assert set(d.loc[train, 'shedid']).isdisjoint(set(d.loc[test, 'shedid']))
            model = sm.GLM(y[train], x[train], family=sm.families.Binomial(),
                           freq_weights=w[train]/w[train].mean()).fit()
            pred[test] = model.predict(x[test])
        pred = np.clip(pred, 1e-12, 1-1e-12)
        rows.append({'model': name, 'weighted_Brier': np.average((pred-y)**2, weights=w),
                     'weighted_log_loss': -np.average(y*np.log(pred)+(1-y)*np.log1p(-pred), weights=w),
                     'n': len(d), 'folds': 5})
    return pd.DataFrame(rows)


def run_all():
    scf = run_scf()
    shed = run_shed()
    summary = {'research_date': '2026-10-26', 'scf_waves': [2016, 2019, 2022, 2025],
               'shed_tolerance_waves': [2018, 2019, 2025], 'shed_prospective_years': [2024, 2025],
               'within_person': shed['within'],
               'prospective': shed['shed_prospective'].to_dict(orient='records')}
    (OUT/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    return scf, shed


if __name__ == '__main__':
    run_all()
