"""SEBI 2025 age-cohort willingness analysis with explicit sample separation."""
from pathlib import Path
import zipfile,json,re,html,hashlib,gzip
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import statsmodels.api as sm
from age_expense_analysis import ROOT,DATA,OUT,save

NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
COHORTS=['Gen Z','Millennials','Generation X','Baby Boomers']

def extract():
    cache=DATA/'india_analysis_fields.csv.gz'
    if cache.exists():
        manifest=DATA/'india_extract_manifest.json'
        if manifest.exists():
            expected=json.loads(manifest.read_text(encoding='utf-8'))
            if 'extract_uncompressed_sha256' in expected:
                actual=hashlib.sha256(gzip.decompress(cache.read_bytes())).hexdigest()
                assert actual==expected['extract_uncompressed_sha256'], 'Indian analytic extract changed; reconstruct and review its provenance.'
            else:
                assert hashlib.sha256(cache.read_bytes()).hexdigest()==expected['extract_sha256'], 'Indian analytic extract changed; reconstruct and review its provenance.'
        return pd.read_csv(cache,low_memory=False)
    print('Extracting selected SEBI fields from public workbook',flush=True)
    keep={'Resp_ID_DP','UniqueId_DP','SELECTED_STATE','URBANRURAL','Q1','SECNEW','Zone_DP','QFL','SELECTED_CLASS','AOL_VAR_CENTRE',
          'CWE','Q3D','Q5A','Q9','Q10','Q10A','Q13','Q13A','Q14','QRT','INT_TYPE','QLISTMAIN','WeightMainM2','Weight_to_Sample','Life_Stage','CON_ISEC'}
    keep.update(f'Q1MXGrid[{{_{i}}}].Q1M' for i in range(1,6))
    keep.update(f'Q1M_DP[{{_{i}}}].Q1M' for i in range(1,6))
    with zipfile.ZipFile(DATA/'india_respondents.xlsx') as z:
        print('Workbook XML sizes MB:',[(i.filename,round(i.file_size/1e6,1)) for i in z.infolist() if i.filename.endswith('.xml') and i.file_size>1e6],flush=True)
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            with z.open('xl/sharedStrings.xml') as f:
                for event,node in ET.iterparse(f,events=['end']):
                    if node.tag==NS+'si':shared.append(''.join(t.text or '' for t in node.iter(NS+'t')));node.clear()
        def decode(c):
            v=c.find(NS+'v')
            if c.attrib.get('t')=='s':return shared[int(v.text)] if v is not None else None
            if c.attrib.get('t')=='inlineStr':return ''.join(t.text or '' for t in c.iter(NS+'t'))
            return v.text if v is not None else None
        selected={};records=[];labels={}
        with z.open('xl/worksheets/sheet1.xml') as f:
            for event,row in ET.iterparse(f,events=['end']):
                if row.tag!=NS+'row':continue
                idx=int(row.attrib['r'])
                if idx==1:
                    for c in row:
                        v=decode(c)
                        if v in keep:selected[re.sub(r'\d','',c.attrib['r'])]=v
                elif idx==2:
                    for c in row:
                        col=re.sub(r'\d','',c.attrib['r'])
                        if col in selected:labels[selected[col]]=decode(c)
                else:
                    record={}
                    for c in row:
                        col=re.sub(r'\d','',c.attrib['r'])
                        if col in selected:record[selected[col]]=decode(c)
                    records.append(record)
                if idx%20000==0:print('Parsed rows',idx,flush=True)
                row.clear()
    d=pd.DataFrame(records);d.to_csv(cache,index=False,compression='gzip')
    (OUT/'india_selected_field_labels.json').write_text(json.dumps(labels,indent=2),encoding='utf-8')
    return d

def estimate_age():
    d=extract();rows=[];bench=[]
    for c in ['WeightMainM2','Weight_to_Sample']:d[c]=pd.to_numeric(d[c],errors='coerce')
    labels=d.QRT.dropna().unique()
    low=[s for s in labels if s.startswith('Preservation of capital') or s.startswith('I need to have good but stable')]
    high=[s for s in labels if s.startswith('I would like high returns')]
    assert len(low)==2 and len(high)==1 and len(labels)==4
    d['willingness']=(~d.QRT.isin(low)).astype(float);d['high_willingness']=d.QRT.isin(high).astype(float)
    d.loc[d.QRT.isna(),['willingness','high_willingness']]=np.nan
    d['female']=d.Q1.eq('Female').astype(float)
    d['rural']=d.URBANRURAL.eq('Rural').astype(float)
    for label,mask,weight in [('Random interviews',d.INT_TYPE.eq('Random'),'Weight_to_Sample'),
                              ('All supplied records',d.INT_TYPE.notna(),'Weight_to_Sample'),
                              ('Main survey',d.WeightMainM2.gt(0),'WeightMainM2')]:
        f=d.loc[mask&d[weight].gt(0)&d.willingness.notna()&d.Life_Stage.isin(COHORTS)].copy()
        # Source report benchmarks: rounded low-risk shares 80%, Gen Z 79%, oldest85%.
        for cohort,target in [('All',.80),('Gen Z',.79),('Baby Boomers',.85)]:
            g=f if cohort=='All' else f.loc[f.Life_Stage.eq(cohort)]
            value=1-np.average(g.willingness.astype(float),weights=g[weight])
            bench.append({'sample':label,'cohort':cohort,'source_rounded_low_risk_share':target,'recreated':value,'rounds_to_source':round(value*100)==round(target*100),'n':len(g)})
        for cohort in COHORTS:
            g=f.loc[f.Life_Stage.eq(cohort)];w=g[weight].to_numpy();y=g.willingness.to_numpy(dtype=float)
            # HC3 weighted intercept: model-based only, not full complex-design SE.
            r=sm.WLS(y,np.ones((len(g),1)),weights=w).fit(cov_type='HC3')
            rows.append({'sample':label,'specification':'Raw cohort profile','outcome':'willingness','cohort':cohort,
                         'estimate':r.params[0],'se':r.bse[0],'low':r.conf_int()[0,0],'high':r.conf_int()[0,1],'n':len(g)})
        gen=pd.get_dummies(pd.Categorical(f.Life_Stage,categories=COHORTS),prefix='cohort',drop_first=True,dtype=float);gen.index=f.index
        basic=pd.concat([gen,f[['female','rural']]],axis=1)
        region=pd.get_dummies(f.SELECTED_STATE,prefix='state',drop_first=True,dtype=float)
        education=pd.get_dummies(f.Q3D.fillna('Missing'),prefix='education',drop_first=True,dtype=float)
        income=pd.get_dummies(f.Q10.fillna('Missing'),prefix='income',drop_first=True,dtype=float)
        for spec,x in [('Cohort only',gen),('Gender and rural residence',basic),('Income education and state',pd.concat([basic,region,education,income],axis=1))]:
            x=sm.add_constant(x).astype(float);y=f.willingness.astype(float)
            # State-cluster inference is a sensitivity with few heterogeneous
            # regions; neither covariance recovers the withheld survey design.
            r=sm.WLS(y,x,weights=f[weight]).fit(cov_type='HC3')
            term='cohort_Baby Boomers';b=r.params[term];se=r.bse[term]
            rows.append({'sample':label,'specification':spec,'outcome':'oldest_minus_GenZ','cohort':'Baby Boomers minus Gen Z',
                         'estimate':b,'se':se,'low':b-1.96*se,'high':b+1.96*se,'n':len(f)})
            if spec=='Income education and state':
                r=sm.WLS(y,x,weights=f[weight]).fit(cov_type='cluster',cov_kwds={'groups':f.SELECTED_STATE},use_t=True)
                ci=r.conf_int().loc[term];b=r.params[term];se=r.bse[term]
                rows.append({'sample':label,'specification':'Income education state; state-cluster sensitivity','outcome':'oldest_minus_GenZ','cohort':'Baby Boomers minus Gen Z',
                             'estimate':b,'se':se,'low':ci.iloc[0],'high':ci.iloc[1],'n':len(f)})
    save('india_age_effects',pd.DataFrame(rows));save('india_published_benchmarks',pd.DataFrame(bench))
    print(pd.DataFrame(bench).to_string(index=False),flush=True)
    print(pd.DataFrame(rows).loc[lambda x:x.outcome.eq('oldest_minus_GenZ')].to_string(index=False),flush=True)
    # Flow allocations in Q1M are not liquid-asset stocks. They cannot identify
    # months of spending covered and are deliberately excluded from capacity.
    return pd.DataFrame(rows)

def run():
    d=extract()
    print('Indian public workbook records:',len(d),flush=True)
    for c in ['INT_TYPE','Life_Stage','QRT','QLISTMAIN']:
        print(c,d[c].value_counts(dropna=False).to_dict(),flush=True)
    for c in ['WeightMainM2','Weight_to_Sample']:
        d[c]=pd.to_numeric(d[c],errors='coerce')
        print(c,d[c].describe().to_dict(),flush=True)
    if d.UniqueId_DP.duplicated().any():
        raise ValueError('Duplicate respondent IDs: inspect before constructing a cohort')
    save('india_sample_audit',pd.DataFrame([{'measure':'Source records','n':len(d)},
         {'measure':'Random interviews','n':int(d.INT_TYPE.eq('Random').sum())},
         {'measure':'Positive listing weights','n':int(d.Weight_to_Sample.gt(0).sum())},
         {'measure':'Positive main weights','n':int(d.WeightMainM2.gt(0).sum())}]))
    # Use observed response text to avoid inventing ordinal distances or code order.
    responses=d.QRT.dropna().unique().tolist()
    (OUT/'india_response_labels.json').write_text(json.dumps(responses,indent=2),encoding='utf-8')
    # Report source-coded response categories first; a verified coding map is
    # supplied separately after inspecting all response labels and source text.
    summaries=[]
    for label,mask,weight in [('Listing/random',d.INT_TYPE.eq('Random'),'Weight_to_Sample'),
                              ('Main weighted',d.WeightMainM2.gt(0),'WeightMainM2')]:
        f=d.loc[mask&d[weight].gt(0)&d.QRT.notna()&d.Life_Stage.notna()].copy()
        for cohort,g in f.groupby('Life_Stage'):
            for response in responses:
                summaries.append({'sample':label,'cohort':cohort,'response':response,'n':len(g),'weighted_share':np.average(g.QRT.eq(response),weights=g[weight]),'weight_sum':g[weight].sum()})
    save('india_cohort_response_profiles',pd.DataFrame(summaries))
    return d
if __name__=='__main__':run();estimate_age()
