"""Extract public HFCS age profiles without manufacturing household capacity."""
from pathlib import Path
import zipfile,json,re
import numpy as np
import pandas as pd
from age_expense_analysis import ROOT,DATA,OUT,save

COUNTRIES={'IT':'Italy','ES':'Spain','DE':'Germany','FR':'France','NL':'Netherlands',
           'AT':'Austria','BE':'Belgium','PT':'Portugal'}

def numeric(x):
    if pd.isna(x):return np.nan
    if isinstance(x,(int,float)):return float(x)
    s=str(x).strip().replace('(','').replace(')','').replace(',','')
    try:return float(s)
    except ValueError:return np.nan

def extract():
    rows=[];reference=[];notes=[]
    definitions={'C4':'Median financial assets among financial-asset owners, EUR thousands',
                 'A3':'Median net wealth among all households, EUR thousands',
                 'F5':'Median debt-service/income ratio among debt payers, percent',
                 'G3':'Share reporting regular expenses below income, percent'}
    for year in [2021,2023]:
        z=zipfile.ZipFile(DATA/f'hfcs{year}_tables.zip');x=pd.ExcelFile(z.open(z.namelist()[0]))
        for prefix,label in definitions.items():
            sheet=next(s for s in x.sheet_names if s.startswith(prefix+' '));d=pd.read_excel(x,sheet_name=sheet,header=None)
            # Identify country columns and age rows from source cell values,
            # allowing for different worksheet offsets across released vintages.
            header=next(i for i in range(10) if 'DE' in d.iloc[i].astype(str).tolist())
            columns={str(v).strip():j for j,v in enumerate(d.iloc[header]) if str(v).strip() in COUNTRIES}
            start=next(i for i in range(len(d)) if any(str(v).strip()=='Age of RP' for v in d.iloc[i,:4]))
            found=0
            for i in range(start,min(start+15,len(d))):
                labels=[str(v).strip().replace('\u2013','-') for v in d.iloc[i,:4]]
                age=next((v for v in labels if re.fullmatch(r'\d{2}-\d{2}|\d{2}\+',v)),None)
                if age is None:continue
                found+=1
                for code,col in columns.items():
                    rows.append({'wave':year,'country_code':code,'country':COUNTRIES[code],'table':prefix,'measure':label,
                                 'age_group':age,'estimate':numeric(d.iat[i,col]),'published_se':numeric(d.iat[i+1,col]),
                                 'source_sheet':sheet,'source_excel_cell':f'row {i+1}, column {col+1}',
                                 'evidence_level':'Official published aggregate; unadjusted age-group profile'})
            assert found==6,(year,prefix,found)
        refs=pd.read_excel(x,sheet_name='Reference periods',header=None).fillna('')
        reference.append({'wave':year,'published_reference_periods':refs.to_json(orient='values')})
        for s in ['General notes and definitions','Country specific notes']:
            text='\n'.join(' | '.join(str(v) for v in row if pd.notna(v)) for row in pd.read_excel(x,sheet_name=s,header=None).values)
            notes.append({'wave':year,'section':s,'text':text})
    d=save('europe_published_age_profiles',pd.DataFrame(rows));save('europe_reference_periods',pd.DataFrame(reference))
    (OUT/'europe_source_notes.json').write_text(json.dumps(notes,indent=2),encoding='utf-8')
    inventory=[]
    for code,name in COUNTRIES.items():
        inventory.append({'country':name,'dataset':'SHIW and HFCS' if code=='IT' else 'HFCS',
                          'waves':'2016, 2022 microdata; 2021, 2023 public tables' if code=='IT' else '2021, 2023 public tables',
                          'willingness_age_evidence':'SHIW microdata: lower income/wealth-adjusted willingness in both waves; demographic contrast inconclusive' if code=='IT' else 'Not estimated: willingness-by-age absent from downloaded tables',
                          'resilience_age_evidence':'Deposit/expense coverage estimated from SHIW' if code=='IT' else 'Financial resources and debt burden by age only; no household buffer',
                          'public_aggregate_analysis':'Completed: financial assets, net wealth, debt-service burden and saving balance',
                          'respondent_microdata_access':'Italian national files publicly downloaded' if code=='IT' else 'ECB research application required; no application submitted',
                          'source_url':'https://www.ecb.europa.eu/stats/ecb_surveys/hfcs/html/index.en.html',
                          'comparability':'No direct tolerance ranking; no ratio of published medians used as household capacity'})
    save('europe_country_inventory',pd.DataFrame(inventory))
    return d
if __name__=='__main__':
    d=extract();print('Extracted public European age estimates:',len(d));print(d.loc[d.wave.eq(2023)&d.table.eq('C4')].pivot(index='age_group',columns='country',values='estimate').to_string())
