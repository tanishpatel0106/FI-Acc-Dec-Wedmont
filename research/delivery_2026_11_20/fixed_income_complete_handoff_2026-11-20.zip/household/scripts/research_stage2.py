"""Independent replication, longitudinal validation, and spending-constrained scenarios."""
from pathlib import Path
import io, json, zipfile
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import expit
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
from capacity_validation import prepare_shed, SHED_DEMO, SHED_INCOME, hc3_effect

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/stage2'
OUT=ROOT/'outputs/stage2'
OUT.mkdir(parents=True,exist_ok=True)
SEED=20261026


def csv_zip(path, stem=None):
    with zipfile.ZipFile(path) as z:
        member=next(n for n in z.namelist() if n.lower().endswith('.csv') and (stem is None or Path(n).stem.lower()==stem.lower()))
        b=z.read(member)
    try: text=b.decode('utf-8-sig')
    except UnicodeDecodeError: text=b.decode('cp1252')
    return pd.read_csv(io.StringIO(text),low_memory=False)


def write_table(name, data):
    data.to_csv(OUT/f'{name}.csv',index=False)
    return data


def shiw(year):
    yy=str(year%100); path=DATA/f'ind{yy}_ascii.zip'
    def read(stem):
        d=csv_zip(path,stem); d.columns=d.columns.str.upper(); return d
    head=read('carcom'+yy); head=head.loc[head.CFRED.eq(1)].copy()
    assert head.NQUEST.is_unique
    for stem, cols in [('q'+yy+'c2',['RISFIN']),('rfam'+yy,['Y','YL2','YCA2']),
                       ('risfam'+yy,['CN']),('ricfam'+yy,['AF1','AF','W','PF','AF2','AF3']),('debiti'+yy,['RATADEB'])]:
        r=read(stem); head=head.merge(r[['NQUEST']+[c for c in cols if c in r]],on='NQUEST',validate='one_to_one')
    # Remove noncash consumption; rent remains a cash expense. Debt principal is separate.
    head['cash_spending']=head.CN-head.YL2-head.YCA2
    head['buffer_months']=12*head.AF1/head.cash_spending.where(head.cash_spending.gt(0))
    head['buffer_log2']=np.log1p(head.buffer_months)/np.log(2)
    if 'RATADEB' in head:
        # Debt-free households skip repayment questions; a skipped amount is zero only
        # when the separately observed aggregate financial liability is zero.
        head.loc[head.PF.eq(0)&head.RATADEB.isna(),'RATADEB']=0.
        head['buffer_debt_log2']=np.log1p(12*head.AF1/(head.cash_spending+head.RATADEB).where((head.cash_spending+head.RATADEB).gt(0)))/np.log(2)
    head['income_asinh']=np.arcsinh(head.Y/10000)
    head['wealth_asinh']=np.arcsinh(head.W/100000)
    head['age10']=(head.ETA-50)/10
    head['age45plus']=(head.ETA-45).clip(lower=0)/10
    head['age65plus']=(head.ETA-65).clip(lower=0)/10
    head['female']=head.SEX.eq(2).astype(float)
    head['married']=head.STACIV.eq(1).astype(float)
    head['education_highschool']=head.STUDIO.eq(4).astype(float)
    head['education_university']=head.STUDIO.ge(5).astype(float)
    for area in [2,3]: head[f'area{area}']=head.AREA3.eq(area).astype(float)
    head['any_risk']=head.RISFIN.le(3).astype(float).where(head.RISFIN.between(1,4))
    head['high_risk']=head.RISFIN.le(2).astype(float).where(head.RISFIN.between(1,4))
    head['weight']=head.PESOFIT
    rw=read('pesijack'+yy).set_index('NQUEST')
    return head.loc[head.ETA.between(20,89)].copy(),rw


def run_shiw():
    effects=[]; flows=[]; profiles=[]; ages=[]
    controls=['age10','age45plus','age65plus','female','married','NCOMP',
              'education_highschool','education_university','income_asinh','area2','area3']
    for year in [2016,2022]:
        print('Independent SHIW replication:',year,flush=True)
        d,rw=shiw(year)
        flows.append({'year':year,'eligible_households':len(d),'positive_cash_spending':int(d.cash_spending.gt(0).sum()),
                      'risk_observed':int(d.any_risk.notna().sum()),'replicates':rw.shape[1],
                      'weighted_any_risk':np.average(d.any_risk,weights=d.weight),
                      'weighted_buffer_ge3':np.average(d.buffer_months.ge(3),weights=d.weight)})
        for exposure, extra, outcome, spec in [
            ('buffer_log2',[],'any_risk','Primary'),
            ('buffer_log2',['wealth_asinh'],'any_risk','Control net wealth'),
            ('buffer_log2',[],'high_risk','Higher willingness threshold'),
            ('buffer_debt_log2',[],'any_risk','Add annual debt payments to expenses')]:
            if exposure not in d: continue
            f=d.dropna(subset=[exposure,outcome,*controls,*extra]).copy()
            x=sm.add_constant(f[[exposure,*controls,*extra]],has_constant='add').to_numpy(dtype=float)
            y=f[outcome].to_numpy(); w=f.weight.to_numpy()
            def fit(weights):
                return np.linalg.lstsq(x*np.sqrt(weights[:,None]),y*np.sqrt(weights),rcond=None)[0]
            b=fit(w); rep=rw.loc[f.NQUEST].to_numpy(dtype=float)
            br=np.array([fit(rep[:,j]) for j in range(rep.shape[1])])
            # SHIW delete-a-group JKn: scale=1, rscales=1, full-estimate MSE centering.
            se=np.sqrt(((br-b)**2).sum(axis=0))[1]
            effects.append({'year':year,'specification':spec,'outcome':outcome,'n':len(f),'estimate':b[1],
                            'se':se,'low':b[1]-1.96*se,'high':b[1]+1.96*se,'p_normal':2*norm.sf(abs(b[1]/se)),
                            'replicates':rep.shape[1]})
        # Independent check of the original age divergence: different outcome,
        # same age contrast, and no age in either resource outcome definition.
        d['buffer_ge3']=d.buffer_months.ge(3).astype(float).where(d.buffer_months.notna())
        d['government_share']=d.AF2/(d.AF1+d.AF2+d.AF3).where((d.AF1+d.AF2+d.AF3).gt(0))
        age_controls=[c for c in controls if c!='income_asinh']
        for outcome in ['any_risk','buffer_ge3','government_share']:
            f=d.dropna(subset=[outcome,*age_controls]);x=sm.add_constant(f[age_controls],has_constant='add').to_numpy(dtype=float)
            # Age splines at 30 vs 75: age10 +4.5, knot45 +3, knot65 +1.
            contrast=np.zeros(x.shape[1]);contrast[1:4]=[4.5,3.,1.]
            y=f[outcome].to_numpy()
            def statistic(w):
                b=np.linalg.lstsq(x*np.sqrt(w[:,None]),y*np.sqrt(w),rcond=None)[0]
                return contrast@b
            estimate=statistic(f.weight.to_numpy()); rep=rw.loc[f.NQUEST].to_numpy(dtype=float)
            se=np.sqrt(sum((statistic(rep[:,j])-estimate)**2 for j in range(rep.shape[1])))
            ages.append({'year':year,'outcome':outcome,'n':len(f),'age75_minus30':estimate,
                         'se':se,'low':estimate-1.96*se,'high':estimate+1.96*se})
        d['buffer_bin']=pd.cut(d.buffer_months,[-.001,1,3,6,12,np.inf],labels=['<1','1-3','3-6','6-12','12+'],right=False)
        for label,g in d.groupby('buffer_bin',observed=True):
            profiles.append({'year':year,'buffer_months_bin':str(label),'n':len(g),
                             'any_risk':np.average(g.any_risk,weights=g.weight)})
    e=pd.DataFrame(effects)
    mask=e.specification.eq('Primary'); e.loc[mask,'p_holm_two_waves']=multipletests(e.loc[mask,'p_normal'],method='holm')[1]
    write_table('shiw_effects',e);write_table('shiw_sample_flow',pd.DataFrame(flows));write_table('shiw_profiles',pd.DataFrame(profiles))
    write_table('shiw_age_contrasts',pd.DataFrame(ages))
    return e


def shed(year):
    p=DATA/f'SHED_public_use_data_{year}_(CSV).zip'
    if not p.exists(): p=ROOT/'data/capacity_validation'/p.name
    return prepare_shed(csv_zip(p),year)


def matched(a,b):
    assert a.shedid.is_unique and b.shedid.is_unique
    return a.merge(b,on='shedid',suffixes=('_0','_1'),validate='one_to_one')


def run_panel():
    effects=[];descriptive=[]; cross=[];pool=[];sensitivities=[];symmetry=[]
    for first,second in [(2018,2019),(2021,2022)]:
        print('Within-person transition:',first,second,flush=True)
        a,b=shed(first),shed(second)
        if first==2021:
            for year,d in [(first,a),(second,b)]:
                cross.append({'year':year,**hc3_effect(d,'tolerance',SHED_DEMO+SHED_INCOME+['emergency_fund'],'emergency_fund')})
        raw=matched(a,b)
        needed=['tolerance_0','tolerance_1','emergency_fund_0','emergency_fund_1','income_group_0','income_group_1']
        d=raw.dropna(subset=needed).copy()
        d['delta_risk']=d.tolerance_1-d.tolerance_0
        d['delta_fund']=d.emergency_fund_1-d.emergency_fund_0
        d['gain']=d.delta_fund.eq(1).astype(float);d['loss']=d.delta_fund.eq(-1).astype(float)
        d['delta_income']=d.income_group_1-d.income_group_0
        d['later_pair']=float(first==2021)
        weight='panel_weight_1' if 'panel_weight_1' in d else None
        d['analysis_weight']=d[weight] if weight else 1.
        d=d.loc[d.analysis_weight.gt(0)].copy()
        d['analysis_weight']/=d.analysis_weight.mean()
        for change,g in d.groupby('delta_fund'):
            descriptive.append({'pair':f'{first}-{second}','change':int(change),'n':len(g),
                'tolerance_before':np.average(g.tolerance_0,weights=g.analysis_weight),
                'change_tolerance':np.average(g.delta_risk,weights=g.analysis_weight),
                'baseline_income_group':np.average(g.income_group_0,weights=g.analysis_weight),
                'matched_before_complete_cases':len(raw),'baseline_eligible':len(a),
                'weight':'Official follow-up panel weight' if weight else 'Unweighted retained respondents'})
        specifications=[('First difference',['delta_fund','delta_income'],'delta_risk',['delta_fund']),
            ('Gain/loss first difference',['gain','loss','delta_income'],'delta_risk',['gain','loss']),
            ('Baseline-adjusted transition',['gain','loss','tolerance_0','emergency_fund_0','delta_income']+
             [c+'_0' for c in SHED_DEMO+SHED_INCOME],'tolerance_1',['gain','loss'])]
        for spec, predictors,outcome,terms in specifications:
            for term in terms:
                effects.append({'pair':f'{first}-{second}','specification':spec,'term':term,
                    **hc3_effect(d,outcome,predictors,term,weight='analysis_weight')})
            if spec=='Baseline-adjusted transition':
                f=d.dropna(subset=[outcome,*predictors]);x=sm.add_constant(f[predictors],has_constant='add')
                r=sm.WLS(f[outcome],x,weights=f.analysis_weight).fit(cov_type='HC3')
                b=r.params['gain']+r.params['loss']
                se=np.sqrt(r.cov_params().loc[['gain','loss'],['gain','loss']].to_numpy().sum())
                symmetry.append({'pair':f'{first}-{second}','null':'gain + loss = 0','estimate':b,
                                 'se':se,'low':b-1.96*se,'high':b+1.96*se,'p_normal':2*norm.sf(abs(b/se))})
        flagcols=[f'{item}_iflag_{wave}' for item in ['FL0','EF1'] for wave in [0,1]]
        if all(c in d for c in flagcols):
            observed=d.loc[d[flagcols].eq(0).all(axis=1)].copy()
            for spec,predictors,outcome,terms in [specifications[0],specifications[2]]:
                for term in terms:
                    sensitivities.append({'pair':f'{first}-{second}','sensitivity':'No imputed risk or fund items at either visit',
                        'specification':spec,'term':term,**hc3_effect(observed,outcome,predictors,term,weight='analysis_weight')})
        if weight:
            d['unweighted']=1.
            for spec,predictors,outcome,terms in [specifications[0],specifications[2]]:
                for term in terms:
                    sensitivities.append({'pair':f'{first}-{second}','sensitivity':'Unweighted retained panel',
                        'specification':spec,'term':term,**hc3_effect(d,outcome,predictors,term,weight='unweighted')})
        pool.append(d)
    p=pd.concat(pool,ignore_index=True)
    for spec,pred,outcome,terms in [
        ('Pooled first difference',['delta_fund','delta_income','later_pair'],'delta_risk',['delta_fund']),
        ('Pooled baseline-adjusted',['gain','loss','tolerance_0','emergency_fund_0','delta_income','later_pair']+
         [c+'_0' for c in SHED_DEMO+SHED_INCOME],'tolerance_1',['gain','loss'])]:
        f=p.dropna(subset=[outcome,*pred]);x=sm.add_constant(f[pred],has_constant='add')
        r=sm.WLS(f[outcome],x,weights=f.analysis_weight).fit(cov_type='cluster',cov_kwds={'groups':f.shedid})
        for term in terms:
            b=r.params[term];se=r.bse[term]
            effects.append({'pair':'Pooled; respondent clusters','specification':spec,'term':term,'n':len(f),
                'estimate':b,'se':se,'low':b-1.96*se,'high':b+1.96*se,'p_normal':2*norm.sf(abs(b/se))})
    write_table('panel_effects',pd.DataFrame(effects));write_table('panel_transitions',pd.DataFrame(descriptive));
    write_table('shed_new_cross_sections',pd.DataFrame(cross))
    write_table('panel_sensitivities',pd.DataFrame(sensitivities))
    sy=pd.DataFrame(symmetry);sy['p_holm_two_pairs']=multipletests(sy.p_normal,method='holm')[1]
    write_table('panel_symmetry_tests',sy)
    return pd.DataFrame(effects)


PREDICTORS=SHED_DEMO+SHED_INCOME+['unpaid_bills','stable_income']


def prediction_pair(first,second):
    d=matched(shed(first),shed(second))
    ids=set(d.shedid)
    needed=[c+'_0' for c in PREDICTORS+['emergency_fund']]+['unpaid_bills_1','panel_weight_1']
    d=d.dropna(subset=needed).copy();d=d.loc[d.panel_weight_1.gt(0)]
    return d,ids


def fit_logit(x,y,w):
    """Weighted unpenalized Newton fit, with monotone likelihood line search."""
    w=w/w.mean();b=np.zeros(x.shape[1]);b[0]=np.log(np.average(y,weights=w)/(1-np.average(y,weights=w)))
    def loss(v):
        eta=x@v;return np.sum(w*(np.logaddexp(0,eta)-y*eta))
    for _ in range(60):
        p=expit(x@b);h=(x.T*(w*np.maximum(p*(1-p),1e-12)))@x
        step=np.linalg.lstsq(h,x.T@(w*(y-p)),rcond=1e-12)[0]
        old=loss(b); scale=1.
        while loss(b+scale*step)>old+1e-8 and scale>1/1024: scale/=2
        b=b+scale*step
        if np.max(np.abs(scale*step))<1e-7: return b
    raise RuntimeError('Logistic model did not converge')


def scores(y,p,w):
    p=np.clip(p,1e-12,1-1e-12)
    return np.array([np.average((y-p)**2,weights=w),np.average(-y*np.log(p)-(1-y)*np.log1p(-p),weights=w)])


def matrices(d):
    x=sm.add_constant(d[[c+'_0' for c in PREDICTORS]],has_constant='add').to_numpy(dtype=float)
    return [x,np.column_stack([x,d.emergency_fund_0])],d.unpaid_bills_1.to_numpy(),d.panel_weight_1.to_numpy()


def run_prediction(bootstraps=500):
    print('Fitting respondent-disjoint temporal validation',flush=True)
    train,all_train_ids=prediction_pair(2023,2024)
    test0,_=prediction_pair(2024,2025)
    test=test0.loc[~test0.shedid.isin(all_train_ids)].copy()
    assert not set(train.shedid)&set(test.shedid)
    x,y,w=matrices(train);xt,yt,wt=matrices(test)
    fits=[fit_logit(m,y,w) for m in x]
    # Independent library agreement is an implementation check, not another test sample.
    for m,b in zip(x,fits):
        ref=sm.GLM(y,m,family=sm.families.Binomial(),freq_weights=w/w.mean()).fit()
        assert np.max(np.abs(ref.params-b))<1e-5
    predictions=[expit(m@b) for m,b in zip(xt,fits)]
    losses=np.array([scores(yt,p,wt) for p in predictions])
    rng=np.random.default_rng(SEED);rows=[];failed=0
    for i in range(bootstraps):
        a=rng.integers(0,len(y),len(y));b=rng.integers(0,len(yt),len(yt))
        try:
            loss=np.array([scores(yt[b],expit(t[b]@fit_logit(m[a],y[a],w[a])),wt[b]) for m,t in zip(x,xt)])
            rows.append({'replicate':i,'brier_difference':loss[1,0]-loss[0,0],
                         'logloss_difference':loss[1,1]-loss[0,1]})
        except RuntimeError: failed+=1
        if (i+1)%100==0: print('Training-and-test respondent bootstrap:',i+1,flush=True)
    boot=pd.DataFrame(rows); write_table('prediction_bootstrap',boot)
    summary={'train_pair':'2023-2024','test_pair':'2024-2025','n_train':len(train),'n_test_before_exclusion':len(test0),
       'n_test':len(test),'overlap_removed':len(test0)-len(test),'respondent_overlap':0,
       'bootstrap_requested':bootstraps,'bootstrap_successful':len(boot),'bootstrap_failures':failed,
       'baseline_brier':losses[0,0],'fund_brier':losses[1,0],'brier_difference':losses[1,0]-losses[0,0],
       'brier_difference_low':boot.brier_difference.quantile(.025),'brier_difference_high':boot.brier_difference.quantile(.975),
       'baseline_logloss':losses[0,1],'fund_logloss':losses[1,1],'logloss_difference':losses[1,1]-losses[0,1],
       'logloss_difference_low':boot.logloss_difference.quantile(.025),'logloss_difference_high':boot.logloss_difference.quantile(.975),
       'weighted_test_prevalence':np.average(yt,weights=wt)}
    calibration=[];bins=[]
    for name,p in zip(['Baseline','Add emergency fund'],predictions):
        lp=np.log(p/(1-p));r=sm.GLM(yt,sm.add_constant(lp),family=sm.families.Binomial(),freq_weights=wt/wt.mean()).fit(cov_type='HC3')
        calibration.append({'model':name,'intercept':r.params[0],'slope':r.params[1],
                            'mean_predicted':np.average(p,weights=wt),'observed':np.average(yt,weights=wt)})
        # Equal respondent-count bins, with weighted event rates inside bins.
        q=pd.qcut(pd.Series(p),5,labels=False,duplicates='drop').to_numpy()
        for k in np.unique(q):
            mask=q==k;bins.append({'model':name,'bin':int(k),'n':int(mask.sum()),
                'predicted':np.average(p[mask],weights=wt[mask]),'observed':np.average(yt[mask],weights=wt[mask])})
    stability=[]
    # Repeated training perturbations on a fixed external test set; not independent evidence.
    for repeat in range(20):
        a=rng.choice(len(y),int(.8*len(y)),replace=False)
        loss=np.array([scores(yt,expit(t@fit_logit(m[a],y[a],w[a])),wt) for m,t in zip(x,xt)])
        stability.append({'repeat':repeat,'brier_difference':loss[1,0]-loss[0,0]})
    write_table('prediction_training_stability',pd.DataFrame(stability));write_table('prediction_calibration',pd.DataFrame(calibration));write_table('prediction_calibration_bins',pd.DataFrame(bins))
    (OUT/'prediction_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return summary


def market_data():
    x=pd.read_excel(DATA/'damodaran_histretSP.xls',sheet_name='Returns by year',header=19)
    x=x.rename(columns={x.columns[0]:'year',x.columns[1]:'equity',x.columns[3]:'cash'})
    x['year']=pd.to_numeric(x.year,errors='coerce');x=x.loc[x.year.between(1928,2025),['year','equity','cash']].copy()
    x['year']=x.year.astype(int);x[['equity','cash']]=x[['equity','cash']].astype(float)
    inflation=pd.read_excel(DATA/'damodaran_histretSP.xls',sheet_name='Inflation Rate',header=None)
    inflation.columns=['year','inflation_percent','inflation']
    inflation['year']=pd.to_numeric(inflation.year,errors='coerce')
    inflation=inflation.loc[inflation.year.between(1928,2025),['year','inflation']].copy()
    inflation['year']=inflation.year.astype(int);inflation['inflation']=pd.to_numeric(inflation.inflation)
    yields=pd.read_csv(DATA/'gsw_nominal_yields.csv',skiprows=9,parse_dates=['Date'])
    yields=yields.copy()
    yields['year']=yields.Date.dt.year
    # One holiday row (1992-12-31) has no fitted yields. Select the last complete
    # curve in each year, so neither that year nor the next return is silently lost.
    yields=yields.dropna(subset=['SVENY01','SVENY02','SVENY09','SVENY10'])
    annual=yields.loc[yields.year.le(2025)].groupby('year').tail(1).set_index('year')
    bonds=[]
    for year in annual.index:
        if year-1 not in annual.index: continue
        before,after=annual.loc[year-1],annual.loc[year]
        row={'year':year,'curve_date_before':str(before.Date.date()),'curve_date_after':str(after.Date.date())}
        for maturity,name in [(2,'short_bond'),(10,'long_bond')]:
            row[name]=np.expm1(maturity*before[f'SVENY{maturity:02d}']/100-(maturity-1)*after[f'SVENY{maturity-1:02d}']/100)
        bonds.append(row)
    d=x.merge(inflation,on='year',validate='one_to_one').merge(pd.DataFrame(bonds),on='year',validate='one_to_one').dropna()
    assert np.diff(d.year).min()==np.diff(d.year).max()==1
    for c in ['equity','cash','short_bond','long_bond']:
        d[c+'_real']=(1+d[c])/(1+d.inflation)-1
    assert d.year.is_unique and np.isfinite(d.select_dtypes('number')).all().all()
    return write_table('market_annual_returns',d)


def funded_ratios():
    rows=[]
    # Fixed horizons, independent of age; no estimated age coefficient is generated.
    for spending in [4.,6.,8.]:
        for reliable in [0.,2.,4.]:
            for years in [20,30,40]:
                for discount in [0.,.01,.02]:
                    gap=max(spending-reliable,0.)
                    pv=gap*sum((1+discount)**(-t) for t in range(1,years+1))
                    # Assets 100 already include the cash reserve; never add it twice.
                    ratio=100/pv if pv>0 else np.nan
                    pv_shock=max(spending*1.05-reliable,0)*sum((1+discount)**(-t) for t in range(1,years+1))
                    rows.append({'wealth':100,'essential_spending':spending,'reliable_income':reliable,'horizon':years,
                                 'real_discount':discount,'pv_gap':pv,'funded_ratio':ratio,
                                 'pv_gap_with_mean_shock':pv_shock,'funded_ratio_with_mean_shock':100/pv_shock if pv_shock>0 else np.nan,
                                 'surplus_after_funding':100-pv,'gap_fully_covered_by_income':pv==0})
    return write_table('long_term_capacity_scenarios',pd.DataFrame(rows))


def return_paths(returns,paths=12000,years=30,block=5,seed=SEED):
    rng=np.random.default_rng(seed)
    starts=rng.integers(0,len(returns),size=(paths,int(np.ceil(years/block))))
    ix=(starts[:,:,None]+np.arange(block))%len(returns)
    return returns[ix.reshape(paths,-1)[:,:years]]


def simulate(gross,shock_draws,equity_share,reserve_months,bond,spending,reliable_income,phase):
    """Real annual accounting with cash-first withdrawals and proportional investment sales."""
    n,years,_=gross.shape
    cash=np.full(n,reserve_months/12*spending);stocks=np.full(n,100*equity_share)
    bonds=100-cash-stocks
    assert np.all(bonds>=0)
    shortfall=np.zeros(n); ever_shortfall=np.zeros(n,dtype=bool); forced=np.zeros(n);down_sales=np.zeros(n)
    depleted=np.zeros(n,dtype=bool);minimum=np.full(n,100.)
    def pay(amount,cash,stocks,bonds,down):
        available=cash+stocks+bonds;unmet=np.maximum(amount-available,0)
        from_cash=np.minimum(amount,cash);cash=cash-from_cash
        sale=np.minimum(np.maximum(amount-from_cash,0),stocks+bonds)
        fraction=np.divide(sale,stocks+bonds,out=np.zeros(n),where=(stocks+bonds)>0)
        stocks=stocks*(1-fraction);bonds=bonds*(1-fraction)
        return cash,stocks,bonds,unmet,sale,sale*down
    for t in range(years):
        # Income and ordinary essentials arrive at the start of each year. Accumulation
        # has gross labor income = essentials + 2 wealth units; retirement uses the stated pension.
        income=spending+2 if phase=='Accumulation' else reliable_income
        cash=cash+income
        cash,stocks,bonds,unmet,sale,ds=pay(np.full(n,spending),cash,stocks,bonds,np.zeros(n,dtype=bool))
        shortfall+=unmet;ever_shortfall|=unmet>1e-10;forced+=sale
        # Set target weights after regular spending; reserve is part of total wealth.
        total=cash+stocks+bonds
        stocks=equity_share*total
        cash=np.minimum(np.full(n,reserve_months/12*spending),(1-equity_share)*total)
        bonds=total-stocks-cash
        investment_return=equity_share*(gross[:,t,0]-1)+(1-equity_share)*(gross[:,t,bond]-1)
        cash=cash*gross[:,t,1];stocks=stocks*gross[:,t,0];bonds=bonds*gross[:,t,bond]
        # Same 10% annual unexpected essential bill, half one year's essentials, in every strategy.
        bill=shock_draws[:,t]*spending*.5
        cash,stocks,bonds,unmet,sale,ds=pay(bill,cash,stocks,bonds,investment_return<0)
        shortfall+=unmet;ever_shortfall|=unmet>1e-10;forced+=sale;down_sales+=ds
        total=cash+stocks+bonds;minimum=np.minimum(minimum,total);depleted|=total<1e-8
    return {'terminal':cash+stocks+bonds,'shortfall':shortfall,'any_shortfall':ever_shortfall,
            'forced_sales':forced,'down_market_shock_sales':down_sales,'depletion':depleted,'minimum':minimum}


def run_scenarios(paths=12000):
    market=market_data();funded_ratios()
    cols=['equity_real','cash_real','short_bond_real','long_bond_real']
    returns=market[cols].to_numpy(); rng=np.random.default_rng(SEED+10)
    shocks=rng.random((paths,30))<.10
    rows=[];paired=[];sensitivity=[]
    def compare(r,baseline,details,label):
        for metric in ['any_shortfall','terminal','down_market_shock_sales']:
            delta=r[metric].astype(float)-baseline[metric].astype(float)
            se=delta.std(ddof=1)/np.sqrt(paths)
            paired.append({**details,'comparison':label,'metric':metric,'difference':delta.mean(),
                           'mc_se':se,'mc_low':delta.mean()-1.96*se,'mc_high':delta.mean()+1.96*se})
    for block in [5,1]:
        gross=1+return_paths(returns,paths=paths,block=block)
        income_reference={}
        for phase in ['Decumulation','Accumulation']:
            for spending in ([4.,6.,8.] if phase=='Decumulation' else [6.]):
                for income in ([0.,2.,4.] if phase=='Decumulation' else [0.]):
                    for equity in [.4,.6,.8]:
                        outcomes={}
                        for bond,name in [(2,'2-year zero'),(3,'10-year zero')]:
                            for reserve in [0,3,12,24]:
                                r=simulate(gross,shocks,equity,reserve,bond,spending,income,phase)
                                outcomes[(bond,reserve)]=r
                                row={'block_years':block,'phase':phase,'essential_spending':spending,'reliable_income':income,
                                    'equity_share':equity,'reserve_months':reserve,'bond':name,'paths':paths,
                                    'shortfall_probability':r['any_shortfall'].mean(),'depletion_probability':r['depletion'].mean(),
                                    'mean_shortfall':r['shortfall'].mean(),'mean_forced_sales':r['forced_sales'].mean(),
                                    'mean_down_market_shock_sales':r['down_market_shock_sales'].mean(),
                                    'terminal_median':np.median(r['terminal']),'terminal_mean':r['terminal'].mean(),
                                    'terminal_p05':np.quantile(r['terminal'],.05),
                                    'shortfall_mc_se':r['any_shortfall'].std(ddof=1)/np.sqrt(paths)}
                                rows.append(row)
                        detail={'block_years':block,'phase':phase,'essential_spending':spending,'reliable_income':income,'equity_share':equity}
                        for bond,name in [(2,'2-year zero'),(3,'10-year zero')]:
                            compare(outcomes[(bond,12)],outcomes[(bond,0)],{**detail,'bond':name},'12-month reserve minus no reserve; same bond')
                        compare(outcomes[(3,12)],outcomes[(2,12)],{**detail,'bond':'10-year minus 2-year zero'},'Long minus short bond; same 12-month reserve')
                        if phase=='Decumulation':
                            if income==0: income_reference[(spending,equity)]=outcomes[(2,12)]
                            else: compare(outcomes[(2,12)],income_reference[(spending,equity)],{**detail,'bond':'2-year zero'},'Stated pension minus zero pension; same strategy')
        print('Completed paired allocation scenarios; block years:',block,flush=True)
    # Consecutive historical windows assess sensitivity without calling them independent trials.
    history=np.stack([1+returns[start:start+30] for start in range(len(returns)-29)])
    hshocks=np.random.default_rng(SEED+10).random((len(history),30))<.10
    for equity in [.4,.6,.8]:
        for bond,name in [(2,'2-year zero'),(3,'10-year zero')]:
            r=simulate(history,hshocks,equity,12,bond,6,2,'Decumulation')
            for i,start in enumerate(market.year.iloc[:len(history)]):
                sensitivity.append({'start_year':int(start),'equity_share':equity,'bond':name,
                    'shortfall':bool(r['any_shortfall'][i]),'terminal':r['terminal'][i]})
    write_table('allocation_scenarios',pd.DataFrame(rows));write_table('allocation_paired_contrasts',pd.DataFrame(paired));write_table('allocation_historical_windows',pd.DataFrame(sensitivity))
    stress=pd.DataFrame({'instrument':['Cash at par','2-year zero','10-year zero'],
                         'immediate_price_change':[0,np.expm1(-2*.02),np.expm1(-10*.02)]})
    write_table('parallel_rate_stress',stress)
    return pd.DataFrame(rows)


if __name__=='__main__':
    run_shiw();run_panel();print(json.dumps(run_prediction(),indent=2),flush=True);run_scenarios()
