"""SHIW age contrasts with explicit income/wealth conditional estimands."""
import numpy as np
import pandas as pd
from scipy.stats import norm
from research_stage2 import shiw
from age_expense_analysis import save

def run():
    results=[]
    for year in [2016,2022]:
        print('Italian age robustness:',year,flush=True)
        d,rw=shiw(year);d['buffer_ge3']=d.buffer_months.ge(3).astype(float).where(d.buffer_months.notna())
        d['buffer_ge6']=d.buffer_months.ge(6).astype(float).where(d.buffer_months.notna())
        age=['age10','age45plus','age65plus'];demo=['female','married','NCOMP','education_highschool','education_university','area2','area3']
        for label,cols in [('Demographics',age+demo),('Income adjustment',age+demo+['income_asinh']),
                          ('Income and wealth adjustment',age+demo+['income_asinh','wealth_asinh'])]:
            outcomes=['any_risk','buffer_ge3','buffer_ge6'];f=d.dropna(subset=[*cols,*outcomes])
            x=np.column_stack([np.ones(len(f)),f[cols].to_numpy(dtype=float)]);y=f[outcomes].to_numpy()
            w=f.weight.to_numpy()[:,None];rep=rw.loc[f.NQUEST].to_numpy();weights=np.column_stack([w,rep]);k=x.shape[1]
            gram=((x[:,:,None]*x[:,None,:]).reshape(len(x),k*k).T@weights).T.reshape(-1,k,k)
            rhs=((x[:,:,None]*y[:,None,:]).reshape(len(x),k*len(outcomes)).T@weights).T.reshape(-1,k,len(outcomes))
            b=np.linalg.solve(gram,rhs);v=np.zeros(k);v[1:4]=[4.5,3,1]
            values=np.einsum('k,rkq->rq',v,b)
            for j,outcome in enumerate(outcomes):
                estimate=values[0,j];se=np.sqrt(np.sum((values[1:,j]-estimate)**2))
                results.append({'year':year,'specification':label,'outcome':outcome,'estimate':estimate,'se':se,'low':estimate-1.96*se,'high':estimate+1.96*se,'p':2*norm.sf(abs(estimate/se)),'n':len(f)})
    return save('italy_age_contrasts',pd.DataFrame(results))
if __name__=='__main__':print(run().to_string(index=False))
