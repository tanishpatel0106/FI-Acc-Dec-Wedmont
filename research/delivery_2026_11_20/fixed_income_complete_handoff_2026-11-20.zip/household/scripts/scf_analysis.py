"""Transparent SCF 2025 analysis helpers. The notebook displays this source."""
from pathlib import Path
import json
import zipfile
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
OUT = ROOT / 'outputs'
OUT.mkdir(exist_ok=True)
AGE_LABELS = ['20–34', '35–44', '45–54', '55–64', '65–74', '75–89']

def read_zip(name, extension, **kwargs):
    with zipfile.ZipFile(RAW / name) as z:
        member = next(n for n in z.namelist() if n.lower().endswith(extension))
        if extension == '.csv':
            return pd.read_csv(z.open(member), **kwargs)
        return pd.read_stata(z.open(member), convert_categoricals=False, **kwargs)

def load_scf():
    d = read_zip('scfp2025excel.zip', '.csv').copy()
    d['WGT_EXTRACT'] = d['WGT']
    # Summary-extract WGT = X42001/5. Restore per-implicate population weights.
    # Means/regression are scale-invariant, but population totals need this factor.
    d['WGT'] = d['WGT'] * 5
    raw = read_zip('scf2025s.zip', '.dta',
                   columns=['y1', 'yy1', 'x3014', 'x7557', 'x7510', 'x42001'])
    raw.columns = raw.columns.str.upper()
    d = d.merge(raw, on=['Y1', 'YY1'], how='left', validate='one_to_one', indicator=True)
    assert d['_merge'].eq('both').all()
    d = d.drop(columns='_merge').sort_values('Y1').reset_index(drop=True).copy()
    assert np.allclose(d.WGT, d.X42001)
    d['imp'] = d.Y1 % 10
    assert d.groupby('YY1').imp.nunique().eq(5).all()
    assert set(d.imp.unique()) == {1, 2, 3, 4, 5}
    assert np.allclose(d.Y1 // 10, d.YY1)
    r = read_zip('scf2025rw1s.zip', '.dta')
    r = r.set_index('yy1')
    ids = d.loc[d.imp.eq(1), 'YY1'].to_numpy()
    r = r.loc[ids]
    # IMPORTANT: the SCF requires WT1Br * MMr, NOT WT1Br alone.
    rw = np.column_stack([
        r[f'wt1b{i}'].fillna(0).clip(lower=0).to_numpy()
        * r[f'mm{i}'].fillna(0).clip(lower=0).to_numpy()
        for i in range(1, 1000)
    ])
    assert rw.shape == (len(ids), 999)
    base_pop = d.loc[d.imp.eq(1), 'WGT'].sum()
    assert np.max(np.abs(rw.sum(axis=0) / base_pop - 1)) < 0.01
    return d, pd.DataFrame(rw, index=ids)

def prepare(d):
    d = d.copy()
    # The codebook uses -1 for a substantive zero response, not missing.
    assert d.X7557.isin([-1, *range(1, 11)]).all()
    assert d.X3014.isin([1, 2, 3, 4]).all()
    d['tolerance'] = d.X7557.replace(-1, 0).astype(float)
    d['tolerance_ord'] = 4 - d.X3014  # 0=none, 3=substantial; ordered sensitivity
    d['no_risk'] = d.X3014.eq(4).astype(float)
    d['income_log'] = np.log1p(d.NORMINC.clip(lower=0))
    d['payment_headroom'] = 1 - d.PIRTOTAL.clip(lower=0, upper=1)
    d['saving_surplus'] = d.SAVED.astype(float)
    # Descriptive index only: fixed anchors, equal weights, no age or holdings.
    # Income component: log(1+normal income)/log(1+$200,000), capped at 1.
    # This is an investigator-defined financial resilience proxy, not true capacity.
    d['income_resource'] = (d.income_log / np.log1p(200_000)).clip(0, 1)
    d['capacity_proxy'] = d[['income_resource', 'payment_headroom', 'saving_surplus']].mean(axis=1)
    d['capacity_no_saving'] = d[['income_resource', 'payment_headroom']].mean(axis=1)
    # Identifiable bonds outside opaque retirement/managed accounts and mixed funds.
    d['identified_bonds'] = d[['BOND', 'SAVBND', 'TFBMUTF', 'GBMUTF', 'OBMUTF']].sum(axis=1)
    d['bond_cd'] = d.identified_bonds + d.CDS
    d['observable_assets'] = d[['LIQ', 'CDS', 'NMMF', 'STOCKS', 'BOND', 'SAVBND']].sum(axis=1)
    d['bond_share'] = d.identified_bonds / d.FIN.where(d.FIN.gt(0))
    d['bond_cd_share'] = d.bond_cd / d.FIN.where(d.FIN.gt(0))
    d['observable_share'] = d.identified_bonds / d.observable_assets.where(d.observable_assets.gt(0))
    d['owns_bonds'] = d.identified_bonds.gt(0).astype(float)
    # NOT a bond measure: includes cash, insurance, non-equity retirement assets, etc.
    d['non_equity_share'] = 1 - d.EQUITY / d.FIN.where(d.FIN.gt(0))
    d['liquid_years'] = d.LIQ / d.NORMINC.where(d.NORMINC.gt(0))
    d['liquid_buffer_log'] = np.log1p(d.liquid_years.clip(upper=10))
    d['log_fin'] = np.log1p(d.FIN)
    d['age_group'] = pd.cut(d.AGE, [19, 34, 44, 54, 64, 74, 89], labels=AGE_LABELS)
    d['age10'] = (d.AGE - 50) / 10
    d['age45plus'] = (d.AGE - 45).clip(lower=0) / 10
    d['age65plus'] = (d.AGE - 65).clip(lower=0) / 10
    d['female'] = d.HHSEX.eq(2).astype(float)
    d['partnered'] = d.MARRIED.eq(1).astype(float)
    d['children'] = d.KIDS.astype(float)
    for k in [2, 3, 4]:
        d[f'education{k}'] = d.EDCL.eq(k).astype(float)
    for var in ['bond_share', 'bond_cd_share', 'observable_share', 'non_equity_share']:
        assert d[var].dropna().between(-1e-8, 1+1e-8).all(), var
    return d

class Survey:
    """MI point pooling + official 999 bootstrap replicates on implicate 1.

    Total covariance = sample_cov(replicate estimates, ddof=1)
                       + (1+1/5)*sample_cov(5 implicate estimates, ddof=1).
    This follows the Federal Reserve MEANIT / standard-error documentation.
    All CIs are approximate normal intervals; no fivefold pseudo sample size.
    """
    def __init__(self, data, replicate_weights):
        self.data = data
        self.rw = replicate_weights

    def estimate(self, statistic):
        points = []
        for m in range(1, 6):
            frame = self.data.loc[self.data.imp.eq(m)].copy()
            points.append(np.asarray(statistic(frame, frame.WGT.to_numpy()[:, None])).reshape(-1))
        first = self.data.loc[self.data.imp.eq(1)].copy()
        reps = np.asarray(statistic(first, self.rw.loc[first.YY1].to_numpy()))
        points = np.asarray(points)
        reps = reps.reshape(999, -1)
        if not np.isfinite(points).all() or not np.isfinite(reps).all():
            raise ValueError('Undefined estimate: inspect sample size or missing data.')
        cov = np.atleast_2d(np.cov(reps, rowvar=False, ddof=1))
        cov += 1.2 * np.atleast_2d(np.cov(points, rowvar=False, ddof=1))
        return {'estimate': points.mean(axis=0), 'cov': cov, 'implicates': points,
                'replicates': reps, 'se': np.sqrt(np.diag(cov))}

    def means(self, columns, subset=None):
        def statistic(frame, weights):
            mask = np.ones(len(frame), dtype=bool) if subset is None else subset(frame).to_numpy()
            values = frame[columns].to_numpy(dtype=float)
            mask &= np.isfinite(values).all(axis=1)
            w = weights[mask]
            return (w.T @ values[mask]) / w.sum(axis=0)[:, None]
        r = self.estimate(statistic)
        return pd.DataFrame({'estimate': r['estimate'], 'se': r['se'],
                             'low': r['estimate']-1.96*r['se'],
                             'high': r['estimate']+1.96*r['se']}, index=columns)

    def grouped(self, column, group, levels):
        def statistic(frame, weights):
            out = []
            for level in levels:
                mask = frame[group].eq(level).to_numpy() & frame[column].notna().to_numpy()
                w = weights[mask]
                out.append((w.T @ frame.loc[mask, column].to_numpy()) / w.sum(axis=0))
            return np.column_stack(out)
        r = self.estimate(statistic)
        first = self.data.loc[self.data.imp.eq(1)]
        rows = []
        for i, level in enumerate(levels):
            sample = first.loc[first[group].eq(level) & first[column].notna()]
            w = sample.WGT.to_numpy()
            rows.append({'group': level, 'estimate': r['estimate'][i], 'se': r['se'][i],
                         'low': r['estimate'][i]-1.96*r['se'][i],
                         'high': r['estimate'][i]+1.96*r['se'][i],
                         'n_households': len(sample), 'weight_neff': w.sum()**2/(w@w)})
        return pd.DataFrame(rows)

    def correlation(self, x, y):
        def statistic(frame, weights):
            mask = frame[[x, y]].notna().all(axis=1).to_numpy()
            a = frame.loc[mask, x].to_numpy(); b = frame.loc[mask, y].to_numpy()
            w = weights[mask]; total = w.sum(axis=0)
            ma = w.T@a/total; mb = w.T@b/total
            va = w.T@(a*a)/total-ma*ma; vb = w.T@(b*b)/total-mb*mb
            return ((w.T@(a*b)/total-ma*mb)/np.sqrt(va*vb))[:, None]
        return self.estimate(statistic)

def weighted_fit(frame, weights, columns, outcome):
    """Batched WLS; each weight column is a separate survey replicate."""
    x = np.column_stack([np.ones(len(frame)), frame[columns].to_numpy(dtype=float)])
    y = frame[outcome].to_numpy(dtype=float)
    mask = np.isfinite(x).all(axis=1) & np.isfinite(y)
    x = x[mask]; y = y[mask]; w = weights[mask]
    k = x.shape[1]
    gram = ((x[:, :, None] * x[:, None, :]).reshape(len(x), k*k).T @ w).T.reshape(-1, k, k)
    rhs = ((x*y[:, None]).T @ w).T
    return np.linalg.solve(gram, rhs[..., None])[..., 0]

def survey_model(survey, columns, outcome='bond_share'):
    r = survey.estimate(lambda f, w: weighted_fit(f, w, columns, outcome))
    r['columns'] = ['Intercept', *columns]
    r['outcome'] = outcome
    r['table'] = pd.DataFrame({'term': r['columns'], 'estimate': r['estimate'],
                               'se': r['se'], 'low': r['estimate']-1.96*r['se'],
                               'high': r['estimate']+1.96*r['se']})
    return r

def age_design(age, columns):
    values = {'age10': (age-50)/10, 'age45plus': max(age-45, 0)/10,
              'age65plus': max(age-65, 0)/10}
    return np.array([values.get(c, 0.) for c in columns])

def contrast(model, vector, scale=1):
    b = model['estimate']; cov = model['cov']; v = np.asarray(vector)
    point = v@b*scale; se = np.sqrt(max(v@cov@v, 0))*abs(scale)
    return {'estimate': float(point), 'se': float(se), 'low': float(point-1.96*se),
            'high': float(point+1.96*se)}

def age_contrast(model, older=75, younger=30, scale=100):
    return contrast(model, age_design(older, model['columns'])-age_design(younger, model['columns']), scale)

def cross_validate(data, specs, outcome='bond_share', seed=20261019):
    """5 folds by household; all five imputations use the same household fold.

    Weighted test MSE is computed per implicate, then averaged; RMSE is its square root.
    These are descriptive held-out scores, not design-based hypothesis tests.
    """
    ids = np.sort(data.YY1.unique())
    rng = np.random.default_rng(seed)
    shuffled = rng.permutation(ids)
    folds = dict(zip(shuffled, np.arange(len(ids)) % 5))
    rows = []
    for name, cols in specs.items():
        mse_imp = []
        for m in range(1, 6):
            f = data.loc[data.imp.eq(m)].copy()
            fold = f.YY1.map(folds).to_numpy()
            y = f[outcome].to_numpy(); w = f.WGT.to_numpy()
            predictions = np.zeros(len(f))
            for k in range(5):
                train = fold != k; test = fold == k
                assert set(f.loc[train, 'YY1']).isdisjoint(set(f.loc[test, 'YY1']))
                beta = weighted_fit(f.loc[train], w[train, None], cols, outcome)[0]
                x = np.column_stack([np.ones(test.sum()), f.loc[test, cols].to_numpy()])
                predictions[test] = x@beta
            mse_imp.append(np.average((y-predictions)**2, weights=w))
        rows.append({'model': name, 'weighted_test_MSE': np.mean(mse_imp),
                     'weighted_test_RMSE_pp': np.sqrt(np.mean(mse_imp))*100})
    result = pd.DataFrame(rows)
    baseline = result.loc[result.model.eq('Intercept only'), 'weighted_test_MSE'].iloc[0]
    result['CV_R2_vs_intercept'] = 1-result.weighted_test_MSE/baseline
    return result
