"""Age associations under published expense-based liquidity measurement.

Bhutta-Dettling reconstruction is approximate, not a full author-code replication.
All age effects are observational contrasts, not within-person aging effects.
"""
from pathlib import Path
from functools import lru_cache
import json,zipfile
import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
from capacity_validation import read_zip,load_wave,AGE,DEMO
from scf_analysis import Survey,survey_model,age_contrast,contrast

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/age_expense_extension'
OUT=ROOT/'outputs/age_expense_extension';OUT.mkdir(parents=True,exist_ok=True)
CPI={2016:3548,2019:3775,2022:4376,2025:4789}
MONTHLY={-1:0.,0:0.,2:52/12,3:26/12,4:1.,5:1/3,6:1/12,11:1/6,12:.5,20:5/12,23:13/12,24:52/72,31:2.}

def save(name,d):d.to_csv(OUT/f'{name}.csv',index=False);return d

@lru_cache(maxsize=4)
def load_expenses(year,full_sample=False):
    d,rw=load_wave(year)
    # Re-read the summary extract to retain all ages for published descriptive checks.
    folder=ROOT/'data/raw' if year==2025 else ROOT/'data/capacity_validation'
    summary=read_zip(folder/f'scfp{year}excel.zip','.csv');summary.columns=summary.columns.str.upper()
    if full_sample:
        d=summary.copy();d['WGT']=d.WGT*5;d['imp']=d.Y1%10
    rawcols=['y1','yy1','x703','x704','x710','x721','x722','x810',
             'x7001','x2202','x2102','x6351']
    raw=read_zip(folder/f'scf{year}s.zip','.dta',columns=rawcols);raw.columns=raw.columns.str.upper()
    # Expense fields from the summary are expressed in 2025 dollars; raw amounts
    # are survey-year dollars. Put both in 2025 dollars before addition.
    add=[c for c in summary if c not in d and c not in ['Y1','YY1']]
    d=d.merge(summary[['Y1','YY1',*add]],on=['Y1','YY1'],validate='one_to_one')
    d=d.merge(raw,on=['Y1','YY1'],validate='one_to_one')
    scale=4789/CPI[year]
    def monthly(amount,period):
        codes=d[period]
        assert not ((d[amount]>0)&codes.isin([-1,0])).any(), f'Positive amount with undefined frequency: {amount}'
        # Positive amounts with an undocumented, other, or one-time frequency
        # are missing. Do not assume those amounts recur monthly.
        return (d[amount].clip(lower=0)*codes.map(MONTHLY)*scale).where(d[amount]>0,0.)
    d['expense_fees']=monthly('X703','X704')
    tax=monthly('X721','X722')
    tax_escrow=d.X810.isin([1,3])
    insurance_escrow=d.X810.isin([2,3])
    d['expense_taxes_extra']=tax.where(~tax_escrow,0)
    d['expense_observed']=d.TPAY+d.RENT+(d.FOODHOME+d.FOODAWAY+d.FOODDELV)/12+d.expense_fees+d.expense_taxes_extra
    # Footnote-8 imputation constants are 2016-dollar amounts. Maintain the same
    # real constants across survey waves; do not silently use 2016 nominal USD.
    real2016=4789/3548
    owner=d.HOUSES.gt(0);renter_util=d.X710.map({1:0.,3:.05,5:.10}).fillna(.10)
    d['expense_utilities']=np.where(owner,.005*d.HOUSES/12,renter_util*d.RENT)
    d['expense_home_insurance']=np.where(owner&~insurance_escrow,.005*d.HOUSES/12,0)
    vehicles=d.X2202.astype(float).clip(lower=0)+d.X2102.astype(float).clip(lower=0)
    size=d.X7001.astype(float).clip(lower=1);adults=(size-d.KIDS).clip(lower=1)
    # The paper specifies members over 16, while the readily available KIDS
    # aggregate excludes under-18s. This documented approximation is not exact.
    d['expense_other_fixed']=(1200+600*adults+500*vehicles+1000*adults+np.where(vehicles.gt(0),800+600*(vehicles-1),0))/12*real2016
    d['expense_home_maintenance']=np.where(owner,.01*d.HOUSES/12,0)
    health=json.loads((DATA/'bls_health_transcription.json').read_text())['families']
    sizes=size.clip(upper=5).astype(int);ages=np.searchsorted([25,35,45,55,65],d.AGE,side='right')
    d['health_age_group']=ages;d['health_size_group']=sizes
    for use_age,key in [(True,'age'),(False,'noage')]:
        ins=np.empty(len(d));other=np.empty(len(d))
        for i,(s,a) in enumerate(zip(sizes,ages)):
            h=health[str(s)]
            ins[i]=h['insurance'][a] if use_age else h['all_ages'][0]
            other[i]=h['drugs'][a]+h['supplies'][a] if use_age else sum(h['all_ages'][1:])
        ins=pd.Series(ins,index=d.index,dtype=float);paid=d.X6351.eq(1)
        groups=['imp','health_size_group']+(['health_age_group'] if use_age else [])
        for _,idx in d.groupby(groups).groups.items():
            w=d.loc[idx,'WGT'];share=np.average(paid.loc[idx],weights=w)
            # Preserve the source cell mean when assigning insurance to payers.
            ins.loc[idx]=ins.loc[idx]*paid.loc[idx]/share if share>0 else 0
        d[f'expense_health_{key}']=(ins+other)/12*real2016
    fixed=d.expense_utilities+d.expense_home_insurance+d.expense_other_fixed+d.expense_home_maintenance
    d['expense_published']=d.expense_observed+fixed+d.expense_health_age
    d['expense_noage']=d.expense_observed+fixed+d.expense_health_noage
    d['transaction_assets']=d.LIQ
    d['accessible_assets']=d.LIQ+d.STOCKS+d.BOND+d.NMMF
    d['den_income']=d.NORMINC.where(d.NORMINC.gt(0))/12
    d['den_expense']=d.expense_published.where(d.expense_published.gt(0))
    d['den_noage']=d.expense_noage.where(d.expense_noage.gt(0))
    d['den_observed']=d.expense_observed.where(d.expense_observed.gt(0))
    if year==2025:
        # New reported spending explicitly excludes rent and mortgage/loan payments.
        d['den_reported']=(d.TOTSPENDNH/12+d.RENT+d.TPAY).where(lambda x:x.gt(0))
    for assets in ['transaction','accessible']:
        for den in ['income','expense','noage','observed']+(['reported'] if year==2025 else []):
            d[f'{assets}_{den}_months']=d[f'{assets}_assets']/d[f'den_{den}']
            for threshold in [3,6]:
                m=d[f'{assets}_{den}_months'];d[f'{assets}_{den}_ge{threshold}']=m.ge(threshold).astype(float).where(m.notna())
    d['wealth_asinh']=np.arcsinh(d.NETWORTH/100000)
    return d,rw

def fit_many(survey,columns,outcomes):
    """Estimate several outcomes together with identical design and replicates."""
    def statistic(f,w):
        x=np.column_stack([np.ones(len(f)),f[columns].to_numpy(dtype=float)])
        y=f[outcomes].to_numpy(dtype=float)
        mask=np.isfinite(x).all(axis=1)&np.isfinite(y).all(axis=1)
        x=x[mask];y=y[mask];w=w[mask];k=x.shape[1]
        gram=((x[:,:,None]*x[:,None,:]).reshape(len(x),k*k).T@w).T.reshape(-1,k,k)
        rhs=((x[:,:,None]*y[:,None,:]).reshape(len(x),k*len(outcomes)).T@w).T.reshape(-1,k,len(outcomes))
        return np.linalg.solve(gram,rhs).reshape(w.shape[1],-1)
    r=survey.estimate(statistic)
    return r

def run_scf():
    rows=[];profiles=[];audits=[];bench=[]
    for year in [2016,2019,2022,2025]:
        print(f'Expense-based SCF analysis: {year}',flush=True)
        d,rw=load_expenses(year);survey=Survey(d,rw)
        outcomes=['tolerance','any_risk','transaction_income_ge3','transaction_expense_ge3','accessible_income_ge3',
                  'accessible_expense_ge3','accessible_expense_ge6','accessible_noage_ge3','accessible_observed_ge3']
        if year==2025:outcomes+=['transaction_reported_ge3','accessible_reported_ge3']
        specs=[('Demographics',AGE+DEMO),('Income adjustment',AGE+DEMO+['income_log']),
               ('Income and wealth adjustment',AGE+DEMO+['income_log','wealth_asinh'])]
        f=d.copy()
        for a in ['age45plus','age65plus']:f[a]=0.
        specs.append(('Linear age', ['age10',*DEMO]))
        # A second, predeclared piecewise-linear age basis.
        d['age40plus']=(d.AGE-40).clip(lower=0)/10;d['age60plus']=(d.AGE-60).clip(lower=0)/10
        specs.append(('Alternative age knots', ['age10','age40plus','age60plus',*DEMO]))
        for label,cols in specs:
            print('  '+label,flush=True);r=fit_many(survey,cols,outcomes);k=len(cols)+1;q=len(outcomes)
            v=np.array([0]+[4.5 if c=='age10' else 3 if c=='age45plus' else 1 if c=='age65plus' else 3.5 if c=='age40plus' else 1.5 if c=='age60plus' else 0 for c in cols])
            valid=d[[*cols,*outcomes]].notna().all(axis=1)&d.imp.eq(1)
            for j,outcome in enumerate(outcomes):
                full=np.zeros((k,q));full[:,j]=v;full=full.ravel()
                b=float(full@r['estimate']);se=float(np.sqrt(max(full@r['cov']@full,0)))
                rows.append({'year':year,'specification':label,'outcome':outcome,'estimate':b,'se':se,'low':b-1.96*se,'high':b+1.96*se,
                             'p':2*norm.sf(abs(b/se)),'n_households_complete_case':int(valid.sum())})
        # Raw weighted age profiles use each outcome's own nonmissing sample.
        for outcome in ['tolerance','any_risk','transaction_income_ge3','transaction_expense_ge3','accessible_expense_ge3']+(['accessible_reported_ge3'] if year==2025 else []):
            t=survey.grouped(outcome,'age_group',list(d.age_group.cat.categories));t['year']=year;t['outcome']=outcome;profiles.append(t)
        for m in range(1,6):
            g=d.loc[d.imp.eq(m)];w=g.WGT
            def wm(s):
                ok=s.notna();return np.average(s[ok],weights=w[ok])
            audits.append({'year':year,'imp':m,'mean_expenses_2025usd':wm(g.expense_published),
                           'observed_expense_share':wm(g.expense_observed)/wm(g.expense_published),
                           'missing_expense_households':int(g.expense_published.isna().sum()),
                           'mean_income_2025usd':np.average(g.NORMINC,weights=w),
                           'transaction_3income':np.average(g.transaction_income_ge3.dropna(),weights=w[g.transaction_income_ge3.notna()]),
                           'transaction_3expense':wm(g.transaction_expense_ge3),
                           'accessible_3expense':wm(g.accessible_expense_ge3),
                           'accessible_6expense':wm(g.accessible_expense_ge6)})
        if year==2016:
            all_d,_=load_expenses(2016,full_sample=True)
            for name,mask,p3,p6 in [('All ages',all_d.AGE.notna(),.40,.28),('Under35',all_d.AGE.lt(35),.29,.16),
                                   ('Age35-55',all_d.AGE.between(35,55),.33,.21),('Over55',all_d.AGE.gt(55),.50,.39)]:
                for threshold,pub in [(3,p3),(6,p6)]:
                    est=np.mean([np.average(g.dropna(subset=[f'accessible_expense_ge{threshold}'])[f'accessible_expense_ge{threshold}'],weights=g.dropna(subset=[f'accessible_expense_ge{threshold}']).WGT) for _,g in all_d.loc[mask].groupby('imp')])
                    bench.append({'group':name,'threshold_months':threshold,'published':pub,'reconstructed':est,'difference_pp':100*(est-pub),
                                  'status':'Approximate: all ages; public data vintage and explicit expense imputations differ'})
        load_expenses.cache_clear()
    rows=pd.DataFrame(rows);primary=rows.specification.eq('Demographics')&rows.outcome.isin(['tolerance','accessible_expense_ge3'])
    rows.loc[primary,'p_holm_primary8']=multipletests(rows.loc[primary,'p'],method='holm')[1]
    save('scf_age_contrasts',rows);save('scf_age_profiles',pd.concat(profiles));save('scf_expense_audit',pd.DataFrame(audits));save('published_reconstruction',pd.DataFrame(bench))
    return rows

if __name__=='__main__':run_scf()
